leaui_image is a TinyMCE4 image plugin. 

Note: This plugin is bought from "http://leaui.com", it's not part of leanote's open source code.