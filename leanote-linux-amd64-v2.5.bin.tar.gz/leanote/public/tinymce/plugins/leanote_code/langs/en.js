tinymce.addI18n('en',{
	codeLang: "Language",
	toggleCode: "`ctrl+shift+c` toggle code"
});
