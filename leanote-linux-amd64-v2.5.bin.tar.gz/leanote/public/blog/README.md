博客的默认主题和一些公用的静态文件

themes 是默认主题, 有3个

用户自定义的主题不在这里, 在public/upload/userId/thmems下

test
